import sys
import os

codep = 0x400000  
datap = 0x500000  
Memory = [0]*0x600000           

Reg = {
    '00000': 0,'00001': 0,'00010': 0,'00011': 0,'00100': 0,'00101': 0,'00110': 0,'00111': 0,
    '01000': 0,'01001': 0,'01010': 0,'01011': 0,'01100': 0,'01101': 0,'01110': 0,'01111': 0,
    '10000': 0,'10001': 0,'10010': 0,'10011': 0,'10100': 0,'10101': 0,'10110': 0,'10111': 0,
    '11000': 0,'11001': 0,'11010': 0,'11011': 0,'11100': 0x508000,'11101': 0xA00000,'11110': 0xA00000,
    '11111': 0x0,'pc': 0x400000,'hi': 0x0,'lo': 0x0, 'va': 0x500000,'exit': 0,'icounter': 0,
}

def dumpMemory(ic):
    with open('memory_' + str(ic) + '.bin', 'wb') as bin:
        for i in range(len(Memory)):
            bin.write(Memory[i].to_bytes(1, 'big'))

def dumpRegister(ic):
    with open('register_' + str(ic) + '.bin', 'wb') as bin:
        for i, j in enumerate(Reg.values()):
            bin.write((j & 0xFFFFFFFF).to_bytes(4, 'little'))
            if i == 34:
                break

def stoi(s):
    if s.startswith('0x'):
        return int(s, 16)
    elif s.startswith('-0x'):
        return -1 * int(s[1:], 16)
    elif s.startswith('0b'):
        return int(s, 2)
    elif s.startswith('-0b'):
        return -1 * int(s[1:], 2)
    else: 
        return int(s)

def checkDtype(splitedLine, addr):
    if splitedLine[0] == '.ascii':
        addr += len(splitedLine[1])
    elif splitedLine[0] == '.asciiz':
        addr += len(splitedLine[1]) + 1
    elif splitedLine[0] == '.byte':
        addr += 1
    elif splitedLine[0] == '.half':
        addr += 2
    else:
        addr += 4
    return addr


def initD(d):
    if d[0] == '.byte':
        Memory[d[2]] = d[1] & 0xFF
    elif d[0] in ['.ascii', '.asciiz']:
        for j in range(len(d[1])):
            Memory[d[2]+j] = ord(d[1][j])
    elif d[0] == '.half':
        Memory[d[2]] = int('{:#006x}'.format(d[1] & 0xFFFF)[4:6], 16)
        Memory[d[2]+1] = int('{:#006x}'.format(d[1] & 0xFFFF)[0:4], 16)
    elif d[0] == '.word':
        Memory[d[2]] = int('{:#010x}'.format(d[1] & 0xFFFFFFFF)[8:10], 16)
        Memory[d[2]+1] = int('{:#010x}'.format(d[1] & 0xFFFFFFFF)[6:8], 16)
        Memory[d[2]+2] = int('{:#010x}'.format(d[1] & 0xFFFFFFFF)[4:6], 16)
        Memory[d[2]+3] = int('{:#010x}'.format(d[1] & 0xFFFFFFFF)[0:4], 16)
    return Memory


def add(rd, rs, rt):
    Reg[rd] = Reg[rs] + Reg[rt]

def addi(rt, rs, immediate):
    if immediate.startswith('1'):
        val = int(immediate, 2) - int('1'*len(immediate), 2) - 1
    else:
        val = int(immediate, 2)
    Reg[rt] = Reg[rs] + val


def addiu(rt, rs, immediate):
    if immediate.startswith('1'):
        val = int(immediate, 2) - int('1'*len(immediate), 2) - 1
    else:
        val = int(immediate, 2)
    Reg[rt] = int('{:#035b}'.format(Reg[rs] + val)[3:], 2)  


def addu(rd, rs, rt):
    Reg[rd] = int('{:035b}'.format(Reg[rs] + Reg[rt])[3:], 2) 


def and_(rd, rs, rt):  
    Reg[rd] = Reg[rs] & Reg[rt]


def andi(rt, rs, immediate):
    if immediate.startswith('1'):
        val = int(immediate, 2) - int('1'*len(immediate), 2) - 1
    else:
        val = int(immediate, 2)
    Reg[rt] = Reg[rs] & val


def beq(rs, rt, immediate):
    if immediate.startswith('1'):
        val = int(immediate, 2) - int('1'*len(immediate), 2) - 1
    else:
        val = int(immediate, 2)
    if Reg[rs] == Reg[rt]:
        Reg['pc'] += val*4
def bgez(rs, immediate):
    if immediate.startswith('1'):
        val = int(immediate, 2) - int('1'*len(immediate), 2) - 1
    else:
        val = int(immediate, 2)
    if Reg[rs] >= 0:
        Reg['pc'] += val*4
def bgtz(rs, immediate):
    if immediate.startswith('1'):
        val = int(immediate, 2) - int('1'*len(immediate), 2) - 1
    else:
        val = int(immediate, 2)
    if Reg[rs] > 0:
        Reg['pc'] += val*4
def blez(rs, immediate):
    if immediate.startswith('1'):
        val = int(immediate, 2) - int('1'*len(immediate), 2) - 1
    else:
        val = int(immediate, 2)
    if Reg[rs] <= 0:
        Reg['pc'] += val*4
def bltz(rs, immediate):
    if immediate.startswith('1'):
        val = int(immediate, 2) - int('1'*len(immediate), 2) - 1
    else:
        val = int(immediate, 2)
    if Reg[rs] < 0:
        Reg['pc'] += val*4
def bne(rs, rt, immediate):
    if immediate.startswith('1'):
        val = int(immediate, 2) - int('1'*len(immediate), 2) - 1
    else:
        val = int(immediate, 2)
    if Reg[rs] != Reg[rt]:
        Reg['pc'] += val*4
def div(rs, rt):
    Reg['lo'] = Reg[rs] // Reg[rt]
    Reg['hi'] = Reg[rs] % Reg[rt] 
def divu(rs, rt):
    Reg['lo'] = (Reg[rs] // Reg[rt]) & 0xFFFFFFFF
    Reg['hi'] = (Reg[rs] % Reg[rt]) & 0xFFFFFFFF
def JumpTo(immediate):
    spc = '{:#034b}'.format(Reg['pc'])[2:]
    jump_target_addr = spc[0:4] + immediate + '00'
    Reg['pc'] = int(jump_target_addr, 2) - 4
def jal(immediate):
    spc = '{:#034b}'.format(Reg['pc'])[2:]
    Reg['11111'] = Reg['pc'] + 4
    jump_target_addr = spc[0:4] + immediate + '00'
    Reg['pc'] = int(jump_target_addr, 2) - 4
def jalr(rs):
    Reg['11111'] = Reg['pc'] + 4
    Reg['pc'] = Reg[rs] - 4
def jr(rs):
    Reg['pc'] = Reg[rs] - 4

def lb(rt, addr, off):
    if off.startswith('1'):
        off += '1'*(32-len(off))
    exOFF = int(off, 2)

    daddr = int('{:#035b}'.format(Reg[addr] + exOFF)[3:], 2)
    bits = Memory[daddr - 0x00400000]
    bitss = '{:#010b}'.format(bits)[2:]
    if bitss[0] == '1':
        bitss += '1'*(32-len(bitss))
    exBits = int(bitss, 2)
    Reg[rt] = exBits

def lbu(rt, addr, off):
    if off.startswith('1'):
        off += '1'*(32-len(off))
    exOFF = int(off, 2)

    daddr = int('{:#035b}'.format(Reg[addr] + exOFF)[3:], 2)
    bits = Memory[daddr - 0x00400000]
    Reg[rt] = bits

def lh(rt, addr, off):
    if off.startswith('1'):
        off += '1'*(32-len(off))
    exOFF = int(off, 2)
    daddr = int('{:#035b}'.format(Reg[addr] + exOFF)[3:], 2)
    bitss = '{:#010b}'.format(Memory[daddr - 0x00400000 + 1])[
        2:] + '{:#010b}'.format(Memory[daddr - codep])[2:]

    if bitss.startswith('1'):
        bitss += '1'*(32-len(bitss))
    exBits = int(bitss, 2)
    if bitss.startswith('1'):
        exBits = - ((-exBits) & 0xFFFFFFFF)
    Reg[rt] = exBits

def lhu(rt, addr, off):
    if off[0] == '1':
        off += '1'*(32-len(off))
    exOFF = int(off, 2)
    daddr = int('{:#035b}'.format(Reg[addr] + exOFF)[3:], 2)
    bitss = '{:#010b}'.format(Memory[daddr - 0x00400000 + 1])[
        2:] + '{:#010b}'.format(Memory[daddr - codep])[2:]
    Reg[rt] = int(bitss, 2)

def lui(rt, immediate):
    Reg[rt] = (int(immediate, 2) << 16)

def lw(rt, addr, off):
    if off[0] == '1':
        off += '1'*(32-len(off))
    exOFF = int(off, 2)
    daddr = int('{:#035b}'.format(Reg[addr] + exOFF)[3:], 2)

    bitss = '{:#010b}'.format(Memory[daddr - 0x00400000+3])[2:] + \
                   '{:#010b}'.format(Memory[daddr - 0x00400000+2])[2:] + \
                   '{:#010b}'.format(Memory[daddr - 0x00400000+1])[2:] + \
                   '{:#010b}'.format(Memory[daddr - 0x00400000])[2:]
    if bitss[0] == '1':
        bitss += '1'*(32-len(bitss))
    exBits = int(bitss, 2)
    if bitss[0] == '1':
        exBits = - ((-exBits) & 0xFFFFFFFF)
    Reg[rt] = exBits

def lwl(rt, addr, off):
    if off[0] == '1':
        off += '1'*(32-len(off))
    exOFF = int(off, 2)
    daddr_str = '{:#035b}'.format(Reg[addr] + exOFF)[3:]
    daddr_aligned = daddr_str[:30] + '00'
    daddr = int(daddr_aligned, 2)
    rt_str = '{:#034b}'.format((Reg[rt]) & 0xFFFFFFFF)[2:]

    if daddr_str.endswith('00'):
        rt3 = '{:#010b}'.format(Memory[daddr - 0x00400000])[2:]
        rt2 = rt_str[8:16]
        rt1 = rt_str[16:24]
        rt0 = rt_str[24:32]
    elif daddr_str.endswith('01'):
        rt3 = '{:#010b}'.format(Memory[daddr - 0x00400000 + 1])[2:]
        rt2 = '{:#010b}'.format(Memory[daddr - 0x00400000])[2:]
        rt1 = rt_str[16:24]
        rt0 = rt_str[24:32]
    elif daddr_str.endswith('10'):
        rt3 = '{:#010b}'.format(Memory[daddr - 0x00400000 + 2])[2:]
        rt2 = '{:#010b}'.format(Memory[daddr - 0x00400000 + 1])[2:]
        rt1 = '{:#010b}'.format(Memory[daddr - 0x00400000])[2:]
        rt0 = rt_str[24:32]
    elif daddr_str.endswith('11'):
        rt3 = '{:#010b}'.format(Memory[daddr - 0x00400000 + 3])[2:]
        rt2 = '{:#010b}'.format(Memory[daddr - 0x00400000 + 2])[2:]
        rt1 = '{:#010b}'.format(Memory[daddr - 0x00400000 + 1])[2:]
        rt0 = '{:#010b}'.format(Memory[daddr - 0x00400000])[2:]

    final_data = int(rt3 + rt2 + rt1 + rt0, 2)
    if rt3.startswith('1'):
        final_data = -((-final_data) & 0xFFFFFFFF)
    Reg[rt] = final_data

def lwr(rt, addr, off):
    if off[0] == '1':
        off += '1'*(32-len(off))
    exOFF = int(off, 2)
    daddr_str = '{:#035b}'.format(Reg[addr] + exOFF)[3:]
    daddr_aligned = daddr_str[:30] + '00'
    daddr = int(daddr_aligned, 2)
    rt_str = '{:#034b}'.format((Reg[rt]) & 0xFFFFFFFF)[2:]

    if daddr_str.endswith('00'):
        rt3 = '{:#010b}'.format(
            Memory[daddr - codep + 3])[2:]
        rt2 = '{:#010b}'.format(
            Memory[daddr - codep + 2])[2:]
        rt1 = '{:#010b}'.format(
            Memory[daddr - codep + 1])[2:]
        rt0 = '{:#010b}'.format(Memory[daddr - codep])[2:]
    elif daddr_str.endswith('01'):
        rt3 = rt_str[0: 8]
        rt2 = '{:#010b}'.format(
            Memory[daddr - codep + 3])[2:]
        rt1 = '{:#010b}'.format(
            Memory[daddr - codep + 2])[2:]
        rt0 = '{:#010b}'.format(
            Memory[daddr - codep + 1])[2:]
    elif daddr_str.endswith('10'):
        rt3 = rt_str[0: 8]
        rt2 = rt_str[8:16]
        rt1 = '{:#010b}'.format(
            Memory[daddr - codep + 3])[2:]
        rt0 = '{:#010b}'.format(
            Memory[daddr - codep + 2])[2:]
    elif daddr_str.endswith('11'):
        rt3 = rt_str[0: 8]
        rt2 = rt_str[8:16]
        rt1 = rt_str[16:24]
        rt0 = '{:#010b}'.format(
            Memory[daddr - codep + 3])[2:]
    final_data = int(rt3 + rt2 + rt1 + rt0, 2)
    if rt3.startswith('1'):
        final_data = -((-final_data) & 0xFFFFFFFF)
    Reg[rt] = final_data
def mfhi(rd):
    Reg[rd] = Reg['hi']
def mflo(rd):
    Reg[rd] = Reg['lo']
def mthi(rs):
    Reg['hi'] = Reg[rs]
def mtlo(rs):
    Reg['lo'] = Reg[rs]
def mult(rs, rt):
    PRODUCT = Reg[rs] * Reg[rt]
    PRODUCT_Str = '{:#066b}'.format(PRODUCT)[2:]
    Reg['lo'] = int(PRODUCT_Str[32:64], 2)
    Reg['hi'] = int(PRODUCT_Str[0:32], 2)
def multu(rs, rt):
    # Same as above, but unsighned
    PRODUCT = (Reg[rs] & 0xFFFFFFFF) * (Reg[rt] & 0xFFFFFFFF)
    PRODUCT_Str = '{:#066b}'.format(PRODUCT)[2:]
    Reg['lo'] = int(PRODUCT_Str[32:64], 2)
    Reg['hi'] = int(PRODUCT_Str[0:32], 2)
def nor(rd, rs, rt):
    Reg[rd] = ~(Reg[rs] | Reg[rt])
def or_(rd, rs, rt):
    Reg[rd] = (Reg[rs] | Reg[rt])
def ori(rt, rs, immediate):
    if immediate[0] == '1':
        immediateE_INT = int(immediate, 2) - int('1'*len(immediate), 2) - 1
    else:
        immediateE_INT = int(immediate, 2)
    Reg[rt] = Reg[rs] | immediateE_INT
def sb(rt, addr, off):
    if off[0] == '1':
        off += '1'*(32-len(off))
    exOFF = int(off, 2)
    daddr = int('{:#035b}'.format(Reg[addr] + exOFF)[3:], 2)
    Memory[daddr - codep] = int(
        '{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[26:34], 2)
def sh(rt, addr, off):
    if off[0] == '1':
        off += '1'*(32-len(off))
    exOFF = int(off, 2)
    daddr = int('{:#035b}'.format(Reg[addr] + exOFF)[3:], 2)
    Memory[daddr - codep] = int(
        '{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[26:34], 2)
    Memory[daddr - codep +
           1] = int('{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[18:26], 2)
def sll(rd, rt, sa):
    sa = int(sa, 2)
    Reg[rd] = int('{:035b}'.format(Reg[rt] << sa)[3:], 2)
def sllv(rd, rt, rs):
    Reg[rd] = int('{:#035b}'.format(Reg[rt] << Reg[rs])[3:], 2)
def slt(rd, rs, rt):
    if Reg[rs] < Reg[rt]:
        Reg[rd] = 0x1
    else:
        Reg[rd] = 0x0
def slti(rt, rs, immediate):
    if immediate[0] == '1':
        immediateE_INT = int(immediate, 2) - int('1'*len(immediate), 2) - 1
    else:
        immediateE_INT = int(immediate, 2)
    if Reg[rs] < immediateE_INT:
        Reg[rt] = 0x1
    else:
        Reg[rt] = 0x0
def sltiu(rs, rt, immediate):
    if immediate[0] == '1':
        off += '1'*(32-len(immediate))
    EXTEND_immediateE = int(immediate, 2)
    if (Reg[rs] & 0xFFFFFFFF) < EXTEND_immediateE:
        Reg[rt] = 0x1
    else:
        Reg[rt] = 0x0
def sltu(rd, rs, rt):
    if (Reg[rs] & 0xFFFFFFFF) < (Reg[rt] & 0xFFFFFFFF):
        Reg[rd] = 0x1
    else:
        Reg[rd] = 0x0
def sra(rd, rt, sa):
    Reg[rd] = Reg[rt] >> int(sa, 2)
def srav(rd, rt, rs):
    Reg[rd] = Reg[rt] >> Reg[rs]
def srl(rd, rt, sa):
    Reg[rd] = int(
        '0'*int(sa, 2) + ('{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[2:])[0: 32 - int(sa, 2)], 2)
def srlv(rd, rt, rs):
    sa = Reg[rs]
    Reg[rd] = int(
        '0'*sa + ('{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[2:])[0: 32 - sa], 2)
def sub(rd, rs, rt):
    Reg[rd] = Reg[rs] - Reg[rt]
def subu(rd, rs, rt):
    Reg[rd] = int('{:#035b}'.format(Reg[rs] - Reg[rt])[3:], 2)
def sw(rt, addr, off):
    if off[0] == '1':
        off += '1'*(32-len(off))
    exOFF = int(off, 2)
    daddr = int('{:#035b}'.format(Reg[addr] + exOFF)[3:], 2)
    Memory[daddr - codep] = int(
        '{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[26:34], 2)
    Memory[daddr - codep +
           1] = int('{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[18:26], 2)
    Memory[daddr - codep +
           2] = int('{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[10:18], 2)
    Memory[daddr - codep +
           3] = int('{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[2:10], 2)
def swl(rt, addr, off):
    if off[0] == '1':
        off += '1'*(32-len(off))
    exOFF = int(off, 2)
    daddr_str = '{:#035b}'.format(Reg[addr] + exOFF)[3:]
    daddr_aligned = daddr_str[:30] + '00'
    daddr = int(daddr_aligned, 2)

    if daddr_str.endswith('00'):
        Memory[daddr - codep] = int(
            '{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[2:10], 2)
    elif daddr_str.endswith('01'):
        Memory[daddr - codep] = int(
            '{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[10:18], 2)
        Memory[daddr - codep +
               1] = int('{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[2:10], 2)
    elif daddr_str.endswith('10'):
        Memory[daddr - codep] = int(
            '{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[18:26], 2)
        Memory[daddr - codep +
               1] = int('{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[10:18], 2)
        Memory[daddr - codep +
               2] = int('{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[2:10], 2)
    elif daddr_str.endswith('11'):
        Memory[daddr - codep] = int(
            '{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[26:34], 2)
        Memory[daddr - codep +
               1] = int('{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[18:26], 2)
        Memory[daddr - codep +
               2] = int('{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[10:18], 2)
        Memory[daddr - codep +
               3] = int('{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[2:10], 2)
def swr(rt, addr, off):
    if off[0] == '1':
        off += '1'*(32-len(off))
    exOFF = int(off, 2)
    daddr_str = '{:#035b}'.format(Reg[addr] + exOFF)[3:]
    daddr_aligned = daddr_str[:30] + '00'
    daddr = int(daddr_aligned, 2)

    data3 = '{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[26:34]
    data2 = '{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[18:26]
    data1 = '{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[10:18]
    data0 = '{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[2:10]

    if daddr_str.endswith('00'):
        Memory[daddr -
               0x00400000] = int('{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[26:34], 2)
        Memory[daddr - 0x00400000 +
               1] = int('{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[18:26], 2)
        Memory[daddr - 0x00400000 +
               2] = int('{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[10:18], 2)
        Memory[daddr - 0x00400000 +
               3] = int('{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[2:10], 2)
    elif daddr_str.endswith('01'):
        Memory[daddr - 0x00400000 +
               1] = int('{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[26:34], 2)
        Memory[daddr - 0x00400000 +
               2] = int('{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[18:26], 2)
        Memory[daddr - 0x00400000 +
               3] = int('{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[10:18], 2)
    elif daddr_str.endswith('10'):
        Memory[daddr - 0x00400000 +
               2] = int('{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[26:34], 2)
        Memory[daddr - 0x00400000 +
               3] = int('{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[18:26], 2)
    elif daddr_str.endswith('11'):
        Memory[daddr - 0x00400000 +
               3] = int('{:#034b}'.format(Reg[rt] & 0xFFFFFFFF)[26:34], 2)
def xor(rd, rs, rt):
    Reg[rd] = Reg[rs] ^ Reg[rt]
def xori(rt, rs, immediate):
    if immediate[0] == '1':
        immediateE_INT = int(immediate, 2) - int('1'*len(immediate), 2) - 1
    else:
        immediateE_INT = int(immediate, 2)
    Reg[rt] = Reg[rs] ^ immediateE_INT


out = sys.argv[5]
with open(sys.argv[3], 'r') as checkpts:
    cpts = checkpts.read().split()
    for i in range(len(cpts)):
        if cpts[i].startswith('0x'):
            cpts[i] =  int(cpts[i], 16)
        elif cpts[i].startswith('-0x'):
            cpts[i] =  -1 * int(cpts[i][1:], 16)
        elif cpts[i].startswith('0b'):
            cpts[i] =  int(cpts[i], 2)
        elif cpts[i].startswith('-0b'):
            cpts[i] =  -1 * int(cpts[i][1:], 2)
        else: 
            cpts[i] =  int(cpts[i])

with open(sys.argv[4], 'r') as ifile:
    icontent = ifile.read().split('\n')
with open(sys.argv[1], 'r') as asm:
    lines = asm.readlines()
    for i in range(len(lines)):                       
        lines[i] = lines[i].rstrip('\n')      
        lines[i] = lines[i].replace('\t', ' ') 
        lines[i] = lines[i].partition('#')
        lines[i] = lines[i][0]
        lines[i] = lines[i].partition(':')
        lines[i] = [''.join(lines[i][:2]), lines[i][2]]
    processedF = []
    for i in lines:
        for j in i:                                    
            processedF.append(j)
    for i in processedF:                              
        if i.isspace() == True:                        
            processedF.remove(i)                        
    processedF = [x for x in processedF if x != '']        
    processedF = [x.strip() for x in processedF]             

    dc = []                                   
    if processedF.index('.data')  == 0:                                 
        for i in range(1, processedF.index('.text')):
            dc.append(processedF[i])
    else:                                             
        for i in range(processedF.index('.data') , len(processedF)):
            dc.append(processedF[i])

    nd = []
    for i in range(len(dc)):
        if dc[i].endswith(':') == False:
            if '"' in dc[i]:
                dc[i] = dc[i].split('"')
                for j in range(len(dc[i])):
                    dc[i][j] = eval('"%s"' % dc[i][j])  
                for j in range(len(dc[i])):
                    if j % 2 != 0:
                        nd.append(
                            [dc[i][0].strip(), dc[i][j]])
            else:
                dc[i] = dc[i].strip()
                dc[i] = list(dc[i].partition(' '))
                dc[i][2] = dc[i][2].split(',')
                for j in range(len(dc[i][2])):
                    nd.append([dc[i][0], stoi(dc[i][2][j])])
    for i in range(len(nd)):
        if nd[i][0] in ['.ascii', '.asciiz', '.word']:
            if Reg['va'] % 4 == 1:
                Reg['va'] += 3
            elif Reg['va'] % 4 == 2:
                Reg['va'] += 2
            elif Reg['va'] % 4 == 3:
                Reg['va'] += 1
        elif nd[i][0] == '.half':
            if Reg['va'] % 2 == 1:
                Reg['va'] += 1
        nd[i].append(Reg['va'] - 0x00400000)
        Reg['va'] = checkDtype(nd[i], Reg['va'])

with open(sys.argv[2], 'r') as Machine_Code:
    mclst = Machine_Code.read().split()
    for i in range(len(mclst)):
        mclst[i] = [mclst[i][24:32], mclst[i]
                        [16:24], mclst[i][8:16], mclst[i][0:8]]
        for j in range(4):
            mclst[i][j] = int(mclst[i][j], 2)
    machinecode = []
    for i in mclst:
        for j in i:                                
            machinecode.append(j)

    for i in range(len(machinecode)):
        Memory[i] = machinecode[i]

def syscall():
    syscall_code = Reg['00010']
    if syscall_code == 1:
        with open(out, 'a') as o:
            o.write(str(Reg['00100']))
    elif syscall_code == 4:
        daddr = Reg['00100']
        while Memory[daddr - 0x00400000] != 0:
            with open(out, 'a') as o:
                o.write(chr(Memory[daddr - 0x00400000]))
            daddr += 1
    elif syscall_code == 5:
        Reg['00010'] = int(icontent[Reg['icounter']])
        Reg['icounter'] += 1
    elif syscall_code == 8:
        Str = icontent[Reg['icounter']]
        if len(Str) < Reg['00101']:
            for i in range(0, len(Str)):
                Memory[Reg['00100'] - 0x00400000 + i] = ord(Str[i])
            Memory[Reg['00100'] - 0x00500000 + len(Str)] = 0
        else:
            for i in range(Reg['00101']):
                Memory[Reg['00100'] - 0x00400000 + i] = ord(Str[i])
            Memory[Reg['00100'] - 0x00400000 + Reg['00101']] = 0
        Reg['icounter'] += 1
    elif syscall_code == 9:
        Reg['00010'] = Reg['va']
        Reg['va'] += Reg['00100']
        if Reg['va'] % 4 == 1:
            Reg['va'] += 3
        elif Reg['va'] % 4 == 2:
            Reg['va'] += 2
        elif Reg['va'] % 4 == 1:
            Reg['va'] += 1
        else:
            Reg['va'] = Reg['va']
    elif syscall_code == 10 or syscall_code == 17:
        Reg['exit'] = 1
    elif syscall_code == 11:
        with open(out, 'a') as o:
            o.write(chr(Reg['00100']))
    elif syscall_code == 12:
        Reg['00010'] = ord(icontent[Reg['icounter']])
        Reg['icounter'] += 1
    elif syscall_code == 13:
        fname = ''
        fnAddr = Reg['00100']
        while Memory[fnAddr - 0x00400000] != 0:
            fname += chr(Memory[fnAddr - 0x00400000])
            fnAddr += 1
        Reg['00100'] = os.open(fname, os.O_RDWR | os.O_CREAT)
    elif syscall_code == 14:
        text_read = os.read(Reg['00100'], Reg['00110'])
        Reg['00100'] = Reg['00110']
        for i in range(0, len(text_read)):
            Memory[Reg['00101'] - 0x00400000 + i] = text_read[i]
    elif syscall_code == 15:
        text_write = b''
        for i in range(0, Reg['00110']):
            text_write += (Memory[Reg['00101'] -
                           0x400000 + i]).to_bytes(1, 'big')
        Reg['00100'] = os.write(Reg['00100'], text_write)
    elif syscall_code == 16:
        os.close(Reg['00100'])

if __name__ == '__main__':
    for i in range(len(nd)):
        Memory = initD(nd[i])
    instrucionCounter = 0
    while True:
        if instrucionCounter in cpts:
            dumpMemory(instrucionCounter)
            dumpRegister(instrucionCounter)
        instrucionCounter += 1
        instruction = '{:#010b}'.format(Memory[Reg['pc']-0x00400000+3])[2:]
        instruction += '{:#010b}'.format(Memory[Reg['pc']-0x00400000+2])[2:]
        instruction += '{:#010b}'.format(Memory[Reg['pc']-0x00400000+1])[2:]
        instruction += '{:#010b}'.format(Memory[Reg['pc']-0x00400000])[2:]
        op = instruction[0: 6]
        rs = instruction[6:11]
        rt = instruction[11:16]
        rd = instruction[16:21]
        sa = instruction[21:26]
        fcode = instruction[26:32]
        immed = instruction[16:32]
        target = instruction[6:32]
        if op == '000000':
            if fcode == '100000':
                add(rd, rs, rt)
            elif fcode == '100001':
                addu(rd, rs, rt)
            elif fcode == '100100':
                and_(rd, rs, rt)
            elif fcode == '011010':
                div(rs, rt)
            elif fcode == '011011':
                divu(rs, rt)
            elif fcode == '001001':
                jalr(rs)
            elif fcode == '001000':
                jr(rs)
            elif fcode == '010000':
                mfhi(rd)
            elif fcode == '010010':
                mflo(rd)
            elif fcode == '010001':
                mthi(rs)
            elif fcode == '010011':
                mtlo(rs)
            elif fcode == '011000':
                mult(rs, rt)
            elif fcode == '011001':
                multu(rs, rt)
            elif fcode == '100111':
                nor(rd, rs, rt)
            elif fcode == '100101':
                or_(rd, rs, rt)
            elif fcode == '000000':
                sll(rd, rt, sa)
            elif fcode == '000100':
                sllv(rd, rt, rs)
            elif fcode == '101010':
                slt(rd, rs, rt)
            elif fcode == '101011':
                sltu(rd, rs, rt)
            elif fcode == '000011':
                sra(rd, rt, sa)
            elif fcode == '000111':
                srav(rd, rt, rs)
            elif fcode == '000010':
                srl(rd, rt, sa)
            elif fcode == '000110':
                srlv(rd, rt, rs)
            elif fcode == '100010':
                sub(rd, rs, rt)
            elif fcode == '100011':
                subu(rd, rs, rt)
            elif fcode == '001100':
                syscall()
            elif fcode == '100110':
                xor(rd, rs, rt)
        elif op == '000001' and rt == '00000':
            bltz(rs, immed)
        elif op == '000001' and rt == '00001':
            bgez(rs, immed)
        elif op == '000010':
            JumpTo(target)
        elif op == '000011':
            jal(target)
        elif op == '000100':
            beq(rs, rt, immed)
        elif op == '000101':
            bne(rs, rt, immed)
        elif op == '000110':
            blez(rs, immed)
        elif op == '000111':
            bgez(rs, immed)
        elif op == '001000':
            addi(rt, rs, immed)
        elif op == '001001':
            addiu(rt, rs, immed)
        elif op == '001010':
            slti(rt, rs, immed)
        elif op == '001011':
            sltiu(rt, rs, immed)
        elif op == '001100':
            andi(rt, rs, immed)
        elif op == '001101':
            ori(rt, rs, immed)
        elif op == '001110':
            xori(rt, rs, immed)
        elif op == '001111':
            lui(rt, immed)
        elif op == '100000':
            lb(rt, rs, immed)
        elif op == '100001':
            lh(rt, rs, immed)
        elif op == '100010':
            lwl(rt, rs, immed)
        elif op == '100011':
            lw(rt, rs, immed)
        elif op == '100100':
            lbu(rt, rs, immed)
        elif op == '100101':
            lhu(rt, rs, immed)
        elif op == '100110':
            lwr(rt, rs, immed)
        elif op == '101000':
            sb(rt, rs, immed)
        elif op == '101001':
            sh(rt, rs, immed)
        elif op == '101010':
            swl(rt, rs, immed)
        elif op == '101011':
            sw(rt, rs, immed)
        elif op == '101110':
            swr(rt, rs, immed)
        Reg['pc'] += 4
        if Reg['exit']:
            break
