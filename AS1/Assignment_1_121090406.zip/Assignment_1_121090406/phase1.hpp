#ifndef PHASE1_CPP
#define PHASE1_CPP
#include <map>
#include <iostream>
#include <string>
#include<vector>
#include<utility>
#include<fstream>

bool existCommend1(std::vector<std::string> splitedLine);
void inputFile1(std::ifstream &is);
bool isBlankLine1(std::string line);
std::vector<std::string> splitLine1(std::string line);
std::string removeComment1(std::string line);
bool existLabel1(std::string line);
void phase1(std::map<std::string, long long> &labels);
#endif