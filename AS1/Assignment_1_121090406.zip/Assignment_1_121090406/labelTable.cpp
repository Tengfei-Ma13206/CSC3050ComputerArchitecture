#ifndef labelTable_cpp
#define labelTable_cpp
#include <map>
#include <string>
static std::map<std::string, long long> labels;
#endif