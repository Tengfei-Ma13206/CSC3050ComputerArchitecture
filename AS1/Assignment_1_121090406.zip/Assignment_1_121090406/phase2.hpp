#ifndef PHASE2_CPP
#define PHASE2_CPP
#include <map>
#include <iostream>
#include <string>
#include<vector>
#include<utility>
#include<fstream>

bool existCommend2(std::vector<std::string> splitedLine);
void inputFile2(std::ifstream &is);
bool isBlankLine2(std::string line);
std::vector<std::string> splitLine2(std::string line);
std::string removeComment2(std::string line);
bool existLabel2(std::string line);
void initialize_reg();
std::string decimalToComplementCode(std::string decimalNumber, int digits);
std::string toMachineCode(std::vector<std::string> instruction, long long pc, std::map<std::string, long long> &labels);
void phase2(std::map<std::string, long long> &labels);

#endif
