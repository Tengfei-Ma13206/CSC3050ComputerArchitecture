#include"phase2.hpp"

std::map<std::string, std::string> reg;

void phase2(std::map<std::string, long long> &labels)
{
    initialize_reg();
    std::ifstream is;
    std::ofstream os("output.txt");
    long long pc = 0x400000;
    inputFile2(is);

    std::string line;
    while(getline(is, line)) 
    {
        if(removeComment2(line).find(".text")!=std::string::npos) break;
    }
    while(getline(is, line))
    {
        line = removeComment2(line);
        if (isBlankLine2(line)) continue;
        std::vector<std::string> splitedLine = splitLine2(line);
        if (!existCommend2(splitedLine)) continue;
        std::vector<std::string> commend;

        for(int i = 0; i < splitedLine.size(); i++)
        {
            if (splitedLine[i].find(":") == std::string::npos) commend.push_back(splitedLine[i]);  
        }
        if (commend.size() != 0) 
        {
            os << toMachineCode(commend, pc, labels) << std::endl;
            pc += 4;
        }
    }
    is.close();
    os.close();
}



//implement functions
void initialize_reg()
    {
    reg.insert(std::make_pair<std::string, std::string>("$zero", "00000"));
    reg.insert(std::make_pair<std::string, std::string>("$0", "00000"));
    reg.insert(std::make_pair<std::string, std::string>("$at", "00001"));
    reg.insert(std::make_pair<std::string, std::string>("$1", "00001"));
    reg.insert(std::make_pair<std::string, std::string>("$v0", "00010"));
    reg.insert(std::make_pair<std::string, std::string>("$2", "00010"));
    reg.insert(std::make_pair<std::string, std::string>("$v1", "00011"));
    reg.insert(std::make_pair<std::string, std::string>("$3", "00011"));
    reg.insert(std::make_pair<std::string, std::string>("$a0", "00100"));
    reg.insert(std::make_pair<std::string, std::string>("$4", "00100"));
    reg.insert(std::make_pair<std::string, std::string>("$a1", "00101"));
    reg.insert(std::make_pair<std::string, std::string>("$5", "00101"));
    reg.insert(std::make_pair<std::string, std::string>("$a2", "00110"));
    reg.insert(std::make_pair<std::string, std::string>("$6", "00110"));
    reg.insert(std::make_pair<std::string, std::string>("$a3", "00111"));
    reg.insert(std::make_pair<std::string, std::string>("$7", "00111"));
    reg.insert(std::make_pair<std::string, std::string>("$t0", "01000"));
    reg.insert(std::make_pair<std::string, std::string>("$8", "01000"));
    reg.insert(std::make_pair<std::string, std::string>("$t1", "01001"));
    reg.insert(std::make_pair<std::string, std::string>("$9", "01001"));
    reg.insert(std::make_pair<std::string, std::string>("$t2", "01010"));
    reg.insert(std::make_pair<std::string, std::string>("$10", "01010"));
    reg.insert(std::make_pair<std::string, std::string>("$t3", "01011"));
    reg.insert(std::make_pair<std::string, std::string>("$11", "01011"));
    reg.insert(std::make_pair<std::string, std::string>("$t4", "01100"));
    reg.insert(std::make_pair<std::string, std::string>("$12", "01100"));
    reg.insert(std::make_pair<std::string, std::string>("$t5", "01101"));
    reg.insert(std::make_pair<std::string, std::string>("$13", "01101"));
    reg.insert(std::make_pair<std::string, std::string>("$t6", "01110"));
    reg.insert(std::make_pair<std::string, std::string>("$14", "01110"));
    reg.insert(std::make_pair<std::string, std::string>("$t7", "01111"));
    reg.insert(std::make_pair<std::string, std::string>("$15", "01111"));
    reg.insert(std::make_pair<std::string, std::string>("$s0", "10000"));
    reg.insert(std::make_pair<std::string, std::string>("$16", "10000"));
    reg.insert(std::make_pair<std::string, std::string>("$s1", "10001"));
    reg.insert(std::make_pair<std::string, std::string>("$17", "10001"));
    reg.insert(std::make_pair<std::string, std::string>("$s2", "10010"));
    reg.insert(std::make_pair<std::string, std::string>("$18", "10010"));
    reg.insert(std::make_pair<std::string, std::string>("$s3", "10011"));
    reg.insert(std::make_pair<std::string, std::string>("$19", "10011"));
    reg.insert(std::make_pair<std::string, std::string>("$s4", "10100"));
    reg.insert(std::make_pair<std::string, std::string>("$20", "10100"));
    reg.insert(std::make_pair<std::string, std::string>("$s5", "10101"));
    reg.insert(std::make_pair<std::string, std::string>("$21", "10101"));
    reg.insert(std::make_pair<std::string, std::string>("$s6", "10110"));
    reg.insert(std::make_pair<std::string, std::string>("$22", "10110"));
    reg.insert(std::make_pair<std::string, std::string>("$s7", "10111"));
    reg.insert(std::make_pair<std::string, std::string>("$23", "10111"));
    reg.insert(std::make_pair<std::string, std::string>("$t8", "11000"));
    reg.insert(std::make_pair<std::string, std::string>("$24", "11000"));
    reg.insert(std::make_pair<std::string, std::string>("$t9", "11001"));
    reg.insert(std::make_pair<std::string, std::string>("$25", "11001"));
    reg.insert(std::make_pair<std::string, std::string>("$k0", "11010"));
    reg.insert(std::make_pair<std::string, std::string>("$26", "11010"));
    reg.insert(std::make_pair<std::string, std::string>("$k1", "11011"));
    reg.insert(std::make_pair<std::string, std::string>("$27", "11011"));
    reg.insert(std::make_pair<std::string, std::string>("$gp", "11100"));
    reg.insert(std::make_pair<std::string, std::string>("$28", "11100"));
    reg.insert(std::make_pair<std::string, std::string>("$sp", "11101"));
    reg.insert(std::make_pair<std::string, std::string>("$29", "11101"));
    reg.insert(std::make_pair<std::string, std::string>("$fp", "11110"));
    reg.insert(std::make_pair<std::string, std::string>("$30", "11110"));
    reg.insert(std::make_pair<std::string, std::string>("$ra", "11111"));
    reg.insert(std::make_pair<std::string, std::string>("$31", "11111"));
}

std::string decimalToComplementCode(std::string decimalNumber, int digits)
{
    std::string complementCode = "";
    int decimalNumber_int = stoi(decimalNumber);
    if (decimalNumber_int >= 0)
    {
        for (int i = 0; i < digits; i++)
        {
            complementCode = std::to_string(decimalNumber_int % 2) + complementCode;
            decimalNumber_int /= 2;
        }
    }
    else
    {
        decimalNumber_int += 1<<digits;
        for (int i = 0; i < digits; i++)
        {
            complementCode = std::to_string(decimalNumber_int % 2) + complementCode;
            decimalNumber_int /= 2;
        }
    }

    return complementCode;
}


std::string toMachineCode(std::vector<std::string> instruction, long long pc, std::map<std::string, long long> &labels)
{
    std::string machineCode = "";
    //R-type
    if (instruction[0] == "add") machineCode = std::string("000000") + reg.find(instruction[2])->second + reg.find(instruction[3])->second + reg.find(instruction[1])->second + std::string("00000") + std::string("100000");
    else if (instruction[0] == "addu") machineCode = std::string("000000") + reg.find(instruction[2])->second  + reg.find(instruction[3])->second+ reg.find(instruction[1])->second + std::string("00000") + std::string("100001");
    else if (instruction[0] == "and") machineCode = std::string("000000") + reg.find(instruction[2])->second + reg.find(instruction[3])->second+ reg.find(instruction[1])->second + std::string("00000") + std::string("100100");
    else if (instruction[0] == "div") machineCode = std::string("000000") + reg.find(instruction[1])->second + reg.find(instruction[2])->second + std::string("00000") + std::string("00000") + std::string("011010");
    else if (instruction[0] == "divu") machineCode = std::string("000000") + reg.find(instruction[1])->second + reg.find(instruction[2])->second + std::string("00000") + std::string("00000") + std::string("011011");
    else if (instruction[0] == "jalr") machineCode = std::string("000000") + reg.find(instruction[2])->second + std::string("00000") + reg.find(instruction[1])->second + std::string("00000") + std::string("001001");
    else if (instruction[0] == "jr") machineCode = std::string("000000") + reg.find(instruction[1])->second + std::string("00000") + std::string("00000") + std::string("00000") + std::string("001000");
    else if (instruction[0] == "mfhi") machineCode = std::string("000000") + std::string("00000") + std::string("00000") + reg.find(instruction[1])->second + std::string("00000") + std::string("010000");
    else if (instruction[0] == "mflo") machineCode = std::string("000000") + std::string("00000") + std::string("00000") + reg.find(instruction[1])->second + std::string("00000") + std::string("010010");
    else if (instruction[0] == "mthi") machineCode = std::string("000000") + reg.find(instruction[1])->second + std::string("00000") + std::string("00000") + std::string("00000") + std::string("010001");
    else if (instruction[0] == "mtlo") machineCode = std::string("000000") + reg.find(instruction[1])->second + std::string("00000") + std::string("00000") + std::string("00000") + std::string("010011");
    else if (instruction[0] == "mult") machineCode = std::string("000000") + reg.find(instruction[1])->second + reg.find(instruction[2])->second + std::string("00000") + std::string("00000") + std::string("011000");
    else if (instruction[0] == "multu") machineCode = std::string("000000") + reg.find(instruction[1])->second + reg.find(instruction[2])->second + std::string("00000") + std::string("00000") + std::string("011001");
    else if (instruction[0] == "nor") machineCode = std::string("000000") + reg.find(instruction[2])->second + reg.find(instruction[3])->second+ reg.find(instruction[1])->second + std::string("00000") + std::string("100111");
    else if (instruction[0] == "or") machineCode = std::string("000000") + reg.find(instruction[2])->second + reg.find(instruction[3])->second+ reg.find(instruction[1])->second + std::string("00000") + std::string("100101");
    else if (instruction[0] == "sll") machineCode = std::string("000000") + std::string("00000")+ reg.find(instruction[2])->second + reg.find(instruction[1])->second + decimalToComplementCode(instruction[3], 5) + std::string("000000");
    else if (instruction[0] == "sllv") machineCode = std::string("000000") + reg.find(instruction[3])->second+ reg.find(instruction[2])->second + reg.find(instruction[1])->second + std::string("00000") + std::string("000100");
    else if (instruction[0] == "slt") machineCode = std::string("000000") + reg.find(instruction[2])->second + reg.find(instruction[3])->second+ reg.find(instruction[1])->second + std::string("00000") + std::string("101010");
    else if (instruction[0] == "sltu") machineCode = std::string("000000") + reg.find(instruction[2])->second + reg.find(instruction[3])->second+ reg.find(instruction[1])->second + std::string("00000") + std::string("101011");
    else if (instruction[0] == "sra") machineCode = std::string("000000") + std::string("00000") + reg.find(instruction[2])->second + reg.find(instruction[1])->second + decimalToComplementCode(instruction[3], 5) + std::string("000011");
    else if (instruction[0] == "srav") machineCode = std::string("000000") + reg.find(instruction[3])->second+ reg.find(instruction[2])->second + reg.find(instruction[1])->second + std::string("00000") + std::string("000111");
    else if (instruction[0] == "srl") machineCode = std::string("000000") + std::string("00000")+ reg.find(instruction[2])->second + reg.find(instruction[1])->second + decimalToComplementCode(instruction[3], 5)+ std::string("000010");
    else if (instruction[0] == "srlv") machineCode = std::string("000000") + reg.find(instruction[3])->second+ reg.find(instruction[2])->second + reg.find(instruction[1])->second + std::string("00000") + std::string("000110");
    else if (instruction[0] == "sub") machineCode = std::string("000000") + reg.find(instruction[2])->second + reg.find(instruction[3])->second+ reg.find(instruction[1])->second + std::string("00000") + std::string("100010");
    else if (instruction[0] == "subu") machineCode = std::string("000000") + reg.find(instruction[2])->second + reg.find(instruction[3])->second+ reg.find(instruction[1])->second + std::string("00000") + std::string("100011");
    else if (instruction[0] == "syscall") machineCode = std::string("000000") + std::string("00000")  + std::string("00000")  + std::string("00000")  + std::string("00000") + std::string("001100");
    else if (instruction[0] == "xor") machineCode = std::string("000000") + reg.find(instruction[2])->second + reg.find(instruction[3])->second+ reg.find(instruction[1])->second + std::string("00000") + std::string("100110");
    //I-type
    else if (instruction[0] == "addi") machineCode = std::string("001000") + reg.find(instruction[2])->second + reg.find(instruction[1])->second + decimalToComplementCode(instruction[3], 16);
    else if (instruction[0] == "addiu") machineCode = std::string("001001") + reg.find(instruction[2])->second + reg.find(instruction[1])->second + decimalToComplementCode(instruction[3], 16);
    else if (instruction[0] == "andi") machineCode = std::string("001100") + reg.find(instruction[2])->second + reg.find(instruction[1])->second + decimalToComplementCode(instruction[3], 16);
    else if (instruction[0] == "beq") machineCode = std::string("000100") + reg.find(instruction[1])->second + reg.find(instruction[2])->second + decimalToComplementCode(std::to_string((labels.find(instruction[3])->second-4-pc)/4), 16);
    else if (instruction[0] == "bgez") machineCode = std::string("000001") + reg.find(instruction[1])->second + std::string("00001") + decimalToComplementCode(std::to_string((labels.find(instruction[2])->second-4-pc)/4), 16);
    else if (instruction[0] == "bgtz") machineCode = std::string("000111") + reg.find(instruction[1])->second + std::string("00000") + decimalToComplementCode(std::to_string((labels.find(instruction[2])->second-4-pc)/4), 16);
    else if (instruction[0] == "blez") machineCode = std::string("000110") + reg.find(instruction[1])->second + std::string("00000") + decimalToComplementCode(std::to_string((labels.find(instruction[2])->second-4-pc)/4), 16);
    else if (instruction[0] == "bltz") machineCode = std::string("000001") + reg.find(instruction[1])->second + std::string("00000") + decimalToComplementCode(std::to_string((labels.find(instruction[2])->second-4-pc)/4), 16);
    else if (instruction[0] == "bne") machineCode = std::string("000101") + reg.find(instruction[1])->second + reg.find(instruction[2])->second  + decimalToComplementCode(std::to_string((labels.find(instruction[3])->second-4-pc)/4), 16);
    else if (instruction[0] == "lb") machineCode = std::string("100000") + reg.find(instruction[3])->second+ reg.find(instruction[1])->second + decimalToComplementCode(instruction[2], 16);
    else if (instruction[0] == "lbu") machineCode = std::string("100100") + reg.find(instruction[3])->second+ reg.find(instruction[1])->second + decimalToComplementCode(instruction[2], 16);
    else if (instruction[0] == "lh") machineCode = std::string("100001") + reg.find(instruction[3])->second+ reg.find(instruction[1])->second + decimalToComplementCode(instruction[2], 16);
    else if (instruction[0] == "lhu") machineCode = std::string("100101") + reg.find(instruction[3])->second+ reg.find(instruction[1])->second + decimalToComplementCode(instruction[2], 16);
    else if (instruction[0] == "lui") machineCode = std::string("001111") + std::string("00000") + reg.find(instruction[1])->second + decimalToComplementCode(instruction[2], 16);
    else if (instruction[0] == "lw") machineCode = std::string("100011") + reg.find(instruction[3])->second + reg.find(instruction[1])->second + decimalToComplementCode(instruction[2], 16);
    else if (instruction[0] == "ori") machineCode = std::string("001101") + reg.find(instruction[2])->second + reg.find(instruction[1])->second + decimalToComplementCode(instruction[3], 16);
    else if (instruction[0] == "sb") machineCode = std::string("101000") + reg.find(instruction[3])->second + reg.find(instruction[1])->second + decimalToComplementCode(instruction[2], 16);
    else if (instruction[0] == "slti") machineCode = std::string("001010") + reg.find(instruction[2])->second + reg.find(instruction[1])->second + decimalToComplementCode(instruction[3], 16);
    else if (instruction[0] == "sltiu") machineCode = std::string("001011") + reg.find(instruction[2])->second + reg.find(instruction[1])->second + decimalToComplementCode(instruction[3], 16);
    else if (instruction[0] == "sh") machineCode = std::string("101001") + reg.find(instruction[3])->second + reg.find(instruction[1])->second + decimalToComplementCode(instruction[2], 16);
    else if (instruction[0] == "sw") machineCode = std::string("101011") + reg.find(instruction[3])->second + reg.find(instruction[1])->second + decimalToComplementCode(instruction[2], 16);
    else if (instruction[0] == "xori") machineCode = std::string("001110") + reg.find(instruction[2])->second  + reg.find(instruction[1])->second + decimalToComplementCode(instruction[3], 16);
    else if (instruction[0] == "lwl") machineCode = std::string("100010") + reg.find(instruction[3])->second + reg.find(instruction[1])->second + decimalToComplementCode(instruction[2], 16);
    else if (instruction[0] == "lwr") machineCode = std::string("100110") + reg.find(instruction[3])->second + reg.find(instruction[1])->second + decimalToComplementCode(instruction[2], 16);
    else if (instruction[0] == "swl") machineCode = std::string("101010") + reg.find(instruction[3])->second + reg.find(instruction[1])->second + decimalToComplementCode(instruction[2], 16);
    else if (instruction[0] == "swr") machineCode = std::string("101110") + reg.find(instruction[3])->second + reg.find(instruction[1])->second + decimalToComplementCode(instruction[2], 16);
    //J-type
    else if (instruction[0] == "j") machineCode =std::string("000010" ) + decimalToComplementCode(std::to_string(labels.find(instruction[1])->second), 32).substr(4, 26);
    else if (instruction[0] == "jal") machineCode =std::string ("000011") +  decimalToComplementCode(std::to_string(labels.find(instruction[1])->second), 32).substr(4, 26);
    return machineCode;
}

void inputFile2(std::ifstream &is)
{
    while(true)
    {
        std::cout << "please input test file(same as above): ";
        std::string filename;
        std::cin >> filename;
        is.open(filename.c_str());
        if (!is.fail()) break;
        is.clear();
        std::cout << "please try again!" << std::endl;
    }
}

bool isBlankLine2(std::string line)
{
    if (line == "") return true;
    for(int i = 0; i < line.size(); i++)
    {
        if (line[i]!=' ' && line[i]!='\n' && line[i]!='\t' && line[i]!='\0') return false;
    }
    return true;
}

std::vector<std::string> splitLine2(std::string line)
{
    std::string subString = "";
    std::vector<std::string> splitedString;

    for(int i = 0; i < line.size(); i++)
    {
        if (line[i]!=' ' && line[i]!='\n' && line[i]!='\t' && line[i]!='\0' && line[i]!='(' && line[i]!=')' && line[i]!=',')
        {
            subString = subString + line[i];
        }
        else
        {
            if(subString!="")
            {
                splitedString.push_back(subString);
                subString = "";
            }
        }
    }
    if (subString!="") splitedString.push_back(subString);
    return splitedString;
}

std::string removeComment2(std::string line)
{
    int index_of_sharp = -1;
    std::string line_removed_comment = "";
    if (line.find('#') != std::string::npos)
    {
        index_of_sharp = line.find('#');
        if (index_of_sharp == 0) return "";
        for (int i = 0; i < index_of_sharp; i++)
        {
            line_removed_comment = line_removed_comment + line[i];
        }
        return line_removed_comment;
    }
    return line;
}

bool existCommend2(std::vector<std::string> splitedLine)
{
    for (int i = 0; i < splitedLine.size(); i++)
    {
        if(!existLabel2(splitedLine[i])) return true;
    }
    return false;
}

bool existLabel2(std::string line)
{
    if (line.find(':') != std::string::npos) return true;
    return false;
}
