#include<iostream>
#include<fstream>
#include"phase1.hpp"
#include"phase2.hpp"
#include"labelTable.cpp"
int main()
{
    phase1(labels);
    phase2(labels);
    std::string s1, s2;
    std::ifstream is1("output.txt");
    std::cout << "please input expectedoutput file: ";
    std::string expectedFileName;
    std::cin >> expectedFileName;
    std::ifstream is2(expectedFileName);
    bool correctness = true;
    while(true)
    {
        is1 >> s1;
        is2 >> s2;
        // std::cout << s1 << std::endl;
        // std::cout << s2 << std::endl;
        // if (s1 == s2) std::cout << "same" << std::endl;
        // else std::cout << "different" << std::endl;       // you can cancil comment to print every line of the two files.
        if (s1 != s2) 
        {
            std::cout << "YOU DID SOMETHING WRONG :(" << std::endl;
            correctness = false;
            break;
        }
        if (!(is1 || is2)) break;// it will break only when is1 ends and is2 ends.
    }
    if(correctness) std::cout << "ALL PASSED! CONGRATS :)" << std::endl;
    is1.close();
    is2.close();
}