#include"phase1.hpp"
void phase1(std::map<std::string, long long> &labels)
{
    std::ifstream is;
    long long address = 0x400000;
    inputFile1(is);

    std::string line;
    while(getline(is, line)) 
    {
        if(removeComment1(line).find(".text")!=std::string::npos) break;
    }
    while(getline(is, line))
    {
        line = removeComment1(line);
        if (isBlankLine1(line)) continue;
        if (!existLabel1(line))
        {
            address+=4;
            continue;
        }

        std::vector<std::string> splitedLine = splitLine1(line);

        for(int i = 0; i < splitedLine.size(); i++)
        {
            std::string temp = splitedLine[i];
            int colonIndex = -1;
            while(temp.find(":") != std::string::npos)//deal with label1:label2:label3:, there is no space between labels
            {
                colonIndex = temp.find(":");
                labels.insert(std::pair<std::string, long long>(temp.substr(0, colonIndex), address));
                if(colonIndex+1 != temp.size()) temp = temp.substr(colonIndex+1);
                else break;
            }
        }

        if(existCommend1(splitedLine)) address += 4;
    } 
    is.close();
}




//implement some functions
void inputFile1(std::ifstream &is)
{
    while(true)
    {
        std::cout << "please input test file: ";
        std::string filename;
        std::cin >> filename;
        is.open(filename.c_str());
        if (!is.fail()) break;
        is.clear();
        std::cout << "please try again!" << std::endl;
    }
}

bool isBlankLine1(std::string line)
{
    if (line == "") return true;
    for(int i = 0; i < line.size(); i++)
    {
        if (line[i]!=' ' && line[i]!='\n' && line[i]!='\t' && line[i]!='\0') return false;
    }
    return true;
}

std::vector<std::string> splitLine1(std::string line)
{
    std::string subString = "";
    std::vector<std::string> splitedString;

    for(int i = 0; i < line.size(); i++)
    {
        if (line[i]!=' ' && line[i]!='\n' && line[i]!='\t' && line[i]!='\0' && line[i]!='(' && line[i]!=')' && line[i]!=',')
        {
            subString = subString + line[i];
        }
        else
        {
            if(subString!="")
            {
                splitedString.push_back(subString);
                subString = "";
            }
        }
    }
    if (subString!="") splitedString.push_back(subString);
    return splitedString;
}

std::string removeComment1(std::string line)
{
    int index_of_sharp = -1;
    std::string line_removed_comment = "";
    if (line.find('#') != std::string::npos)
    {
        index_of_sharp = line.find('#');
        if (index_of_sharp == 0) return "";
        for (int i = 0; i < index_of_sharp; i++)
        {
            line_removed_comment = line_removed_comment + line[i];
        }
        return line_removed_comment;
    }
    return line;
}

bool existCommend1(std::vector<std::string> splitedLine)
{
    for (int i = 0; i < splitedLine.size(); i++)
    {
        if(!existLabel1(splitedLine[i])) return true;
    }
    return false;
}

bool existLabel1(std::string line)
{
    if (line.find(':') != std::string::npos) return true;
    return false;
}
